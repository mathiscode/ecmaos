# ecmash

`man @ecmaos/coreutils/ecmash`

## Synopsis

```
ecmash [-l] [-c COMMAND [NAME [ARG...]]] [FILE [ARG...]]
```

## Description

The ecmaOS shell as a real program. It runs in its own worker like any other command, runs the same shell language as the shell built into the kernel (one shared parser, expander, interpreter and set of builtins), and reaches the system only through syscalls: `spawn`, `waitpid` and `killpg` for processes, `pipe` for pipelines, `open` for redirections, and the terminal ioctls for its line editor.

With no command and no file it reads commands from standard input. When that is a terminal it is interactive: a prompt (`$PS1`), line editing, and history in `~/.ecmash_history`. `^C` cancels the line being typed; while a pipeline runs, a stage killed by `SIGINT` stops the rest of that pipeline.

## Options

- `-c COMMAND` - run COMMAND, then exit. The next word is `$0`, the rest are `$1...`
- `-l, --login` - act as a login shell: set the variables in `/etc/environment` (`NAME=value` lines, no expansion), read `/etc/profile`, every `*.sh` in `/etc/profile.d`, then the first of `~/.bash_profile`, `~/.ecmash_profile` or `~/.profile`. Started with an `argv[0]` beginning with `-` (`-ecmash`) it does the same. An interactive shell also reads `/etc/ecmashrc`, `~/.bashrc` and `~/.ecmashrc`

## Scripts

`/bin/sh` is a link to `ecmash`, and `/usr/bin/env` is a link to the `env` program, so a script
starting `#!/bin/sh` or `#!/usr/bin/env sh` runs on `ecmash`. `/bin/bash` is GNU bash, not a link to `ecmash`. It is a
bash-like shell, so a script written for POSIX `sh` runs unchanged; there is no stricter POSIX mode.

## Language

Simple commands, pipelines, `&&`, `||`, `;`, `&`; the redirections `<`, `>`, `>>`, `2>`, `2>&1`, here-documents and here-strings; `$var`, `${...}`, `$(...)`, `$((...))`, globbing; `if`, `while`, `for`, `case`, `{ ...; }` groups, `( ... )` subshells, indexed arrays (`a=(x y)`, `a+=(z)`, `a[i]=v`, `${a[@]}`, `${#a[@]}`), `<(cmd)` and `>(cmd)`, aliases, and functions.

A subshell is a snapshot, not a fork: variables, arrays, functions, aliases, the positional parameters and the working directory are put back afterwards, and `exit` inside ends only the subshell. It has to stand alone (optionally with a redirection); `(a) && b` and `(a) | b` are refused with a message. `<(cmd)` and `>(cmd)` are temporary files, so they do not stream.

Job control: `^Z` stops the foreground job, `jobs` lists, `fg` and `bg` resume, `disown` forgets, and `wait %1` waits for one.

`trap` takes `EXIT`, `ERR`, `DEBUG`, `RETURN`, `INT`, `HUP`, `QUIT`, `USR1`, `USR2`, `PIPE`, `ALRM`, `TERM` and `CHLD`. A trap for a signal runs between commands, not in the middle of one. `DEBUG` runs before each simple command (not inside a function, as in bash without `functrace`), and `RETURN` when a function or sourced file finishes.

Also: `(( expression ))` as a command (it is `let`), `$'...'` quoting, `${x@U}`, `@L`, `@u`, `@Q` and `@E`, `case` with `;&` and `;;&`, `declare -n` and `local -n` namerefs (`unset -n`), `[[ -v name ]]`, `$_`, `FUNCNAME`, `BASH_REMATCH`, `printf -v` and `%q`, and `mapfile`/`readarray`. Pathname expansion understands `[[:class:]]` and `[!x]`, looks through any number of directories (`d/*/x`), and follows `shopt`.

Builtins: `:`, `true`, `false`, `cd`, `pwd`, `echo`, `env`, `exit`, `export`, `unset`, `local`, `set --`, `shift`, `read`, `source`, `.`, `eval`, `exec`, `return`, `break`, `continue`, `type`, `command`, `test`, `[`, `wait`, `jobs`, `fg`, `bg`, `disown`, `alias`, `unalias`, `trap`, `declare`, `typeset`, `readonly`, `getopts`, `umask`, `let`, `mapfile`, `readarray`, `shopt`, `printf`, `caller`, `pushd`, `popd`, `dirs`, `help`, `hash`, `times`, `logout`, `fc`, `ulimit`, `complete`, `compgen`, `compopt`, and the `select` loop.

`pushd`, `popd` and `dirs` keep a directory stack (`DIRSTACK` shows it, a subshell gets its own copy). `select NAME in WORDS; do ...; done` prints a numbered menu on standard error, reads the choice into `REPLY` and runs the body with `NAME` set; `PS3` is its prompt. `PROMPT_COMMAND` (a string, or an array whose elements run in order) runs just before each prompt and leaves `$?` as it was. `help [-ds] [PATTERN]` describes the builtins. `fc` lists, re-runs (`-s`, `-e -`) and edits commands from `~/.ecmash_history` (editor: `-e`, `$FCEDIT`, `$EDITOR`, then `vim`). `compgen [-abcdefgjksuv] [-A ACTION] [-G GLOB] [-W WORDS] [-X FILTER] [-P PREFIX] [-S SUFFIX] [WORD]` prints the candidates for WORD, one per line, and works in a script. `complete` registers how a command's arguments are completed (`-W`, `-A`, `-F FUNCTION`, `-C COMMAND`, `-o default|dirnames|filenames|nospace|plusdirs|nosort`, `-D` for any command, `-E` for an empty line, `-I` for the first word; `-p` prints and `-r` removes), and Tab uses it in both shells. A `-F` function runs in the shell with `COMP_WORDS`, `COMP_CWORD`, `COMP_LINE` and `COMP_POINT` set and fills `COMPREPLY`; its arguments are the command, the word being completed and the word before it; returning 124 makes the spec be looked up again; `compopt` inside it changes the options of that completion. A function's candidates are offered as it returns them (it should filter them, as bash's does). The `bash-completion` package's helpers (`_init_completion` and the rest) are not provided. `logout` ends a login shell and refuses in any other. There is no command location cache, so `hash` only checks that a name can be found (and refuses `-p`), and `times` says it is not available, since a browser keeps no CPU accounting. `ulimit` reports only what is true: `-f` is the machine's file size cap (the one real limit, the same for every process), `-c` is 0 because no core file is written, `-p` and the priorities are fixed, and the rest are unlimited. Setting a limit to the value it already has succeeds, so `ulimit -c 0` and `ulimit -n unlimited` work in scripts; raising one is refused as it is for an unprivileged user, and lowering one is refused because nothing would enforce it.

`shopt [-pqsu] [NAME...]` changes the options that matter here: `nullglob` (a pattern with no match expands to nothing), `failglob` (it is an error), `dotglob` (wildcards match a leading dot), `nocaseglob` and `nocasematch` (ignore case in pathnames, and in `case` and `[[`), `extglob` (`@(a|b)`, `?(..)`, `*(..)`, `+(..)`, `!(..)`) and `globstar` (`**` matches any number of directories). `checkwinsize`, `cmdhist`, `histappend`, `huponexit` and `progcomp` are accepted and remembered, since they only concern an interactive session. Any other name is an error rather than silently ignored.

`umask [-p] [-S] [MODE]` shows or sets the file mode creation mask, octal (`022`) or symbolic (`u=rwx,g=rx,o=rx`, what stays allowed). It applies to the files and directories the shell and everything it starts create, including `>` redirections, and a program inherits it from the shell that ran it. `/etc/profile` sets 022 for a login shell, and pid 1 starts with 022. Programs create files with at most their own 0644 (and directories 0777), so a mask can tighten what they create and cannot loosen it. It needs a newer `@zenfs/core` than the published 2.7.6; without one `umask` says so and fails instead of pretending.

## Differences from the shell built into the kernel

Associative arrays (`declare -A`, `m[key]=v`, `m=([k]=v)`, `${!m[@]}`) work, though a key listing is in insertion order, not bash's hash order. A compound command (`while`, `{ }`, `( )`, ...) or a function can be a pipeline stage; it runs in the shell process, as a subshell, after the pipeline's programs are started. A compound command in the background (`(cmd) &`, `{ ...; } &`, `while ...; done &`) runs in a fresh `ecmash` that is given a copy of the shell's variables, arrays, functions, aliases, options and positional parameters, so it behaves as a forked subshell would (traps are reset, as in bash); a compound stage inside a background pipeline is refused. `read -t` times out. `declare -i` converts assignments to arithmetic, and `read -n` and `-d` take their input from a file or pipe. `set` takes the options bash lists (see `set`); the ones nothing here reads are accepted and read back, and an unknown one is refused. `exec COMMAND` runs the command and exits with its status, since a worker cannot replace itself.

Output redirected to a file is written to a scratch file and copied over when the command finishes. The root filesystem loses data when a file is written in several chunks through a plain descriptor, and a whole-file write is the safe way.

## See also

`chsh`, `/etc/shells`, `skel`, and a page for every builtin (`man pushd`, `man trap`, `man test` and so on; `help` lists them, and a test keeps the two in step).
