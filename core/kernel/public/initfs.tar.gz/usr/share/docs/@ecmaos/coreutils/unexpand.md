# unexpand

`man @ecmaos/coreutils/unexpand`

## Synopsis

```
unexpand [OPTION]... [FILE]...
```

## Description

Convert blanks in each FILE to tabs, writing to standard output. With no FILE, or when FILE is -, read standard input.

## Options

```
  -a, --all        convert all blanks, instead of just initial blanks
      --first-only convert only leading sequences of blanks (overrides -a)
  -t, --tabs=N     have tabs N characters apart instead of 8 (enables -a)
  -t, --tabs=LIST  use comma separated LIST of tab positions (enables -a)
  --help           display this help and exit
```

## See also

`unexpand --help`
