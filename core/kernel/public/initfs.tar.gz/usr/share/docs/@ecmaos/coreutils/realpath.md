# realpath

`man @ecmaos/coreutils/realpath`

## Synopsis

```
realpath [OPTION]... FILE...
```

## Description

Print the resolved absolute file name.

## Options

```
  -e, --canonicalize-existing  all components of the path must exist
  -q, --quiet                  suppress most error messages
  --help                       display this help and exit
```
