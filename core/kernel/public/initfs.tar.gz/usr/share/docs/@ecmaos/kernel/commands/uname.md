# uname

`man @ecmaos/kernel/commands/uname`

## Synopsis

```
uname [OPTION]...
```

## Description

Print system information.

## Options

```
  -a, --all                print all information
  -s, --kernel-name        print the kernel name
  -n, --nodename           print the network node hostname
  -r, --kernel-release     print the kernel release
  -v, --kernel-version     print the kernel version
  -m, --machine            print the machine hardware name
  -p, --processor          print the processor type
  -i, --hardware-platform  print the hardware platform
  -o, --operating-system   print the operating system
  --help                   display this help and exit
```

## See also

`uname --help`
